# Mesh & Picking Completed

Enthält sämtliche **TODOs** der Lektion

[**Tut10_Mesh**](../Tut10_Mesh)
